#include "PROGRAMS/worm-main/allh.h"

/* --- "wnamespace.h" --- */
/* --- Worm namespace --- */
namespace w 
{
    int  ivecL[iD],iT;
    long lvecShift[iD],ldArea,lDVol,lDBonds;
}
//--------------------------------------------------
// D*LLxT is "long" limiting L and T
//--------------------------------------------------
int main ( void )
{
    SysWorm Crnt( "example.sys.in.txt" ); // creating system from INPUT FILE!!!
							              // NEW PRNG, Parameters, Configuration, Statistics
                                          // NEW REPLICA (if needed with randomization)!!!

	Crnt.ReplicaIni (); // nothing bad if no disoder
                        // setting onsite drgMu[i]
                        // calculating exp_Mu[i] +PLUS+ BrknBnds are broken in Crnt array

    Crnt.mC->ConfigurationLoad( "config.txt");
	Crnt.Thermolize ( 10e4 ); // Statistics are not gathered 
	Crnt.Monte ( 10e4 );      // Statistics are collecterd
	Crnt.StatisticsShow();
    	//Crnt.StatisticsCheck();
	Crnt.mC->ConfigurationSave( "config.txt");

	return 0;
}
