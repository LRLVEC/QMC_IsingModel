0) Organize all files from this zip achieve in one folder.

1) Unzip the libraries BIBLIO.zip and PROGRAMS.zip into this folder.

2) In order to compile w-example.cpp, run the following command in that folder:

   g++ w-example.cpp -o w-example.exe

   or use your favorite C++ compiler instead of g++

NOTE: Two folders, BIBLIO and PROGRAMS, MUST be present in the current folder,
      since they contain all necessary classes.

3) This example program calculates (1+1)-dimensional case without disorder.
   The program reads the initial parameters from 'example.sys.in.txt',
   reads the initial configuration from 'config.txt' (prepared for the system size
   set in 'example.sys.in.txt'). Short output of statistics is printed on the screen,
   and the final configuration is saved to 'config.txt'.

4) In order to run the compiled example,
   run the following command in the current folder

   ./w-example.exe

5) See PDF-documentation for a description of the libraries
   and for program organization and additional comments.
